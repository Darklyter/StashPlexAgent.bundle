- Automatic support for getting/creating tag IDs

